export class Tasks {
    protected creationDate: number;
    name: string;
    location: string;
    category: string;
    tip: number;

    constructor() {
        this.creationDate = 0;
        this.name = "";
        this.location = "";
        this.category = "";
        this.tip = 0;
    }

    NewTask(name: string): void {
        console.log(`Setting task name to {name}...`);
        this.name = name;
        console.log(`Task name successfully set to {this.name}`);
    }
}